#warning "This has moved to PhysicsTools/SelectorUtils"
#include "PhysicsTools/SelectorUtils/interface/ElectronVPlusJetsIDSelectionFunctor.h"

