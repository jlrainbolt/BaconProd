#include "FWCore/Utilities/interface/TestHelper.h"

RUNTEST()
