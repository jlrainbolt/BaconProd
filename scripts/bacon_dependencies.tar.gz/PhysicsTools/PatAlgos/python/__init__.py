#Automatically created by SCRAM
import os
__path__.append(os.path.dirname(os.path.abspath(__file__).rsplit('/PhysicsTools/PatAlgos/',1)[0])+'/cfipython/slc6_amd64_gcc530/PhysicsTools/PatAlgos')
