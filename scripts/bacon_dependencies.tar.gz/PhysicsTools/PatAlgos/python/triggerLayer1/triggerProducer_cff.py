import FWCore.ParameterSet.Config as cms

from PhysicsTools.PatAlgos.triggerLayer1.triggerProducer_cfi      import *
from PhysicsTools.PatAlgos.triggerLayer1.triggerEventProducer_cfi import *
