#include "FWCore/Framework/interface/MakerMacros.h"
#include "PhysicsTools/PatAlgos/plugins/PATObjectFilter.h"

using namespace pat;

DEFINE_FWK_MODULE(PATCandViewCountFilter);
