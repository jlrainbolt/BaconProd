#ifndef BTauReco_JetTracksAssociation_h
#define BTauReco_JetTracksAssociation_h

#warning "Including DF/BTau/JTA is deprecated, please include DataFormats/JetReco/interface/JetTracksAssociation.h"
#include "DataFormats/JetReco/interface/JetTracksAssociation.h"

#endif
