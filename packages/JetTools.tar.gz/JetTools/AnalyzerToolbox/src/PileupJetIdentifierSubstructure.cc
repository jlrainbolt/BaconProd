#include "../interface/PileupJetIdentifierSubstructure.h"

#include <iostream>
#include <sstream>
#include <iomanip>
#include <limits>

// ------------------------------------------------------------------------------------------
StoredPileupJetIdentifierSubstructure::StoredPileupJetIdentifierSubstructure() 
{
}

// ------------------------------------------------------------------------------------------
StoredPileupJetIdentifierSubstructure::~StoredPileupJetIdentifierSubstructure() 
{
}

// ------------------------------------------------------------------------------------------
PileupJetIdentifierSubstructure::PileupJetIdentifierSubstructure() 
{
}

// ------------------------------------------------------------------------------------------
PileupJetIdentifierSubstructure::~PileupJetIdentifierSubstructure() 
{
}
