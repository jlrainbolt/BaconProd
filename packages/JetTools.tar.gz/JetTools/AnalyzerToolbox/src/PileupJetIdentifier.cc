#include "../interface/PileupJetIdentifier.h"

#include <iostream>
#include <sstream>
#include <iomanip>
#include <limits>

// ------------------------------------------------------------------------------------------
StoredPileupJetIdentifier::StoredPileupJetIdentifier() 
{
}

// ------------------------------------------------------------------------------------------
StoredPileupJetIdentifier::~StoredPileupJetIdentifier() 
{
}

// ------------------------------------------------------------------------------------------
PileupJetIdentifier::PileupJetIdentifier() 
{
}

// ------------------------------------------------------------------------------------------
PileupJetIdentifier::~PileupJetIdentifier() 
{
}
