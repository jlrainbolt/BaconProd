// File: PFClusterMET.cc
// Description: see PFClusterMET.h
// Author: Salvatore Rappoccio
// Creation Date:  Dec. 2010

#include "DataFormats/METReco/interface/PFClusterMET.h"

using namespace std;
using namespace reco;

//---------------------------------------------------------------------------
// Default Constructor;
//-----------------------------------
PFClusterMET::PFClusterMET()
{
}

