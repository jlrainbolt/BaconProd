#include "DataFormats/METReco/interface/HcalHaloData.h"
/*
  [class]:  HcalHaloData
  [authors]: R. Remington, The University of Florida
  [description]: See HcalHaloData.h
  [date]: October 15, 2009
*/
using namespace reco;
HcalHaloData::HcalHaloData()
{


}
