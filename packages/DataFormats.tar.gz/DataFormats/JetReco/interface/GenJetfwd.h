#warning "GenJetfwd.h is deprecated, use #include DataFormats/JetReco/interface/GenJetCollection.h instead"
#include "DataFormats/JetReco/interface/GenJetCollection.h"
