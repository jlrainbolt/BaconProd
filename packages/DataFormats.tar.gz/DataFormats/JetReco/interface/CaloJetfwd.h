#warning CaloJetfwd.h is deprecated, use #include "DataFormats/JetReco/interface/CaloJetCollection.h" instead
#include "DataFormats/JetReco/interface/CaloJetCollection.h"
