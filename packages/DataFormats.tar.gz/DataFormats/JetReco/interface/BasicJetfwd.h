#warning BasicJetfwd.h is deprecated, use #include "DataFormats/JetReco/interface/BasicJetCollection.h" instead
#include "DataFormats/JetReco/interface/BasicJetCollection.h"
