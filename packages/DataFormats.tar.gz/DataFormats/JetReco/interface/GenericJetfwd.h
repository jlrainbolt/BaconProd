#warning "GenericJetfwd.h is deprecated, use #include DataFormats/JetReco/interface/GenericJetCollection.h instead"
#include "DataFormats/JetReco/interface/GenericJetCollection.h"
