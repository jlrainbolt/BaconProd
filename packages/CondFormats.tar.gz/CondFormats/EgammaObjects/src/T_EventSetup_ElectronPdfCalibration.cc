#include "CondFormats/EgammaObjects/interface/ElectronLikelihoodCalibration.h"
#include "FWCore/Utilities/interface/typelookup.h"

TYPELOOKUP_DATA_REG(ElectronLikelihoodCalibration);
