#include "../interface/GBRForest2D.h"
//#include <iostream>
#include "TMVA/DecisionTree.h"
#include "TMVA/MethodBDT.h"



//_______________________________________________________________________
GBRForest2D::GBRForest2D() : 
  fInitialResponseX(0.),
  fInitialResponseY(0.)
{

}

